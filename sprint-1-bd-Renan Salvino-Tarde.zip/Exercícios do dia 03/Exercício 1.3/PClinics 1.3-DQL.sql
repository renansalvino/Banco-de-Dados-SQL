USE PClinics

SELECT ,DataAtendimento,Descricao FROM Atedimento