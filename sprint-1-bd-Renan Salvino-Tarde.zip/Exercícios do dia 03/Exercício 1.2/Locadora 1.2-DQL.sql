--DQL--
USE Locadora

SELECT  DataInicio,DataFim,idCliente FROM Aluguel

